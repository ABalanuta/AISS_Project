package aiss.main;

public interface Engine {

	
	public void run();
	
	
}
